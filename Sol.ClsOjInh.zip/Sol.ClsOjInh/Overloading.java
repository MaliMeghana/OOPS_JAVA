package ClsObjInh;
import java.util.*;

class MathOp
{
    int multiply(int x, int y, int z)
    {
       int ans=x*y*z;
       return ans;
    }
    double multiply(float x, float y, float z)
    {
       double ans=x*y*z;
       return ans;
    }
    int multiply(int arr[])
    { 
       int ans=1;
       for(int i=0;i<arr.length;i++)
          ans=ans*arr[i];
       return ans;
    }
    double multiply(double x, int y)
    {
       double ans=x*y;
       return ans;
    }
}
class Overloading
{
    public static void main(String args[])
    {
        MathOp m1=new MathOp();
        int arr[]={1,4,6,3,5};
        System.out.println("Multiplication of Integer : "+m1.multiply(2,4,9));
        System.out.println("Multiplication of Float : "+m1.multiply(2.3f,1.1f,1.2f));
        System.out.println("Multiplication of Array element : "+m1.multiply(arr));
        System.out.println("Multiplication of Two datatype : "+m1.multiply(12.8d,4));
    }
}