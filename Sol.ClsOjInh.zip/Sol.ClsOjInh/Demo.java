package ClsObjInh;
import java.util.*;

class MathOperation
{    
    static int sum(int x, int y)
    {
       int sum=x+y;
       return sum;
    }
    static int sub(int x, int y)
    {
       int sub=x-y;
       return sub;
    }
    static int mul(int x, int y)
    {
       int mul=x*y;
       return mul;
    }
    static double pow(int x, int y)
    {
        double pow=Math.pow(x, y);
        return pow;
    }
}
class Demo
{
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter two numbers");
        int x=sc.nextInt();
        int y=sc.nextInt();
        System.out.println("Addition : "+MathOperation.sum(x,y));
        System.out.println("Substraction : "+MathOperation.sub(x,y));
        System.out.println("Multiplication : "+MathOperation.mul(x,y));
        System.out.println("Power : "+MathOperation.pow(x,y));
        
    }
}