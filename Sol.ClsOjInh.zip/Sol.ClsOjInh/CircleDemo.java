package ClsObjInh;
import java.util.*;

class Circle
{
    double radius;
    double area;
    
    void init()
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter radius of circle");
        radius=sc.nextDouble();
    }
    void CalculateArea()
    {
        area=(2*3.14*radius*radius);
    }
    void display()
    {
        System.out.println("Radius : "+radius);
        System.out.println("Area : "+area);
    }
}
class CircleDemo
{
    public static void main(String args[])
    {
        Circle c=new Circle();
        c.init();
        c.CalculateArea();
        c.display();
    }
}