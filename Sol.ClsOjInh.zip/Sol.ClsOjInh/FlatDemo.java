package ClsObjInh;
import java.util.*;

class OneBHK
{
    int roomArea;
    int hallArea;
    int price;
    
    OneBHK(int a1,int a2,int pr)
    {
        roomArea=a1;
        hallArea=a2;
        price=pr;
    }
    void show()
    {
        System.out.println("Room1 Area of Flat : "+roomArea);
        System.out.println("Hall Area of Flat : "+hallArea);
        System.out.println("Price of Flat : "+price);
    }
}
class TwoBHK extends OneBHK
{
    int room2Area;
    TwoBHK(int a1,int a2,int pr,int a3)
    {
        super(a1,a2,pr);
        room2Area=a1;
    }
    void show()
    {
        super.show();
        System.out.println("Room2 Area of Flat : "+room2Area);
    }
}
class FlatDemo
{
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        //a
        TwoBHK to[]=new TwoBHK[3];
        for(int i=0;i<to.length;i++)
        {
            System.out.println("Enter Room1 area,Hall Area, Price and Room2 Area of Flat");
            int r1=sc.nextInt();
            int hall=sc.nextInt();
            int pr=sc.nextInt();
            int r2=sc.nextInt();
            to[i]=new TwoBHK(r1,hall,pr,r2);
        }
        //b
         int total=0;
        for(TwoBHK n:to)
        {
           n.show();
           total=total+n.price;
           System.out.println("**********");
        }
        //c
        System.out.println("Total Amount of all flats : "+total);
      
    }
}