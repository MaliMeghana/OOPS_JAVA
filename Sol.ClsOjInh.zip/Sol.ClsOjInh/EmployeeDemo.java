package ClsObjInh;
import java.util.*;

class Employee
{
    static int empNo=0;
    double salary;
    static double totalSalary=0;
    
    Employee(double s)
    {
        this.salary=s;
        empNo++;
        totalSalary = totalSalary + salary;
    }
    static void display()
    {
        System.out.println("Employee Number : "+empNo);
        System.out.println("Total Salary : "+totalSalary);
    }
}
class EmployeeDemo
{
    public static void main(String args[])
    {
        Employee emp1=new Employee(20000);
        Employee.display();
        Employee emp2=new Employee(30000);        
        Employee emp3=new Employee(40000);
        Employee.display();
        Employee emp4=new Employee(50000);
        Employee emp5=new Employee(60000);
        Employee.display();
        
        
    }
}