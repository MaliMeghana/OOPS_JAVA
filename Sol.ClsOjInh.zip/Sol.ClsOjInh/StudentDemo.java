package ClsObjInh;
import java.util.*;
class Student
{
    int rollno;
    String name;
    
    void setData(int n, String name)
    {
        this.rollno=n;
        this.name=name;
    }
    void showData()
    {
        System.out.println("Roll No = "+rollno);
        System.out.println("Name  = "+name);
    }
    
}
class StudentDemo
{
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter Roll no");
        int n=sc.nextInt();
        System.out.println("Enter Name");
        String name=sc.next();
        Student s=new Student();
        s.setData(n, name);
        System.out.println("Student Detail");
        s.showData();
    }
}