package ClsObjInh;
import java.util.*;

abstract class Processor
{
    int val;
    void showData(int val)
    {
        this.val=val;
        System.out.println("Input Value : "+val);
    }
    abstract  void process(int val);
}
class Factorial extends Processor
{
    void process(int val)
    {
       int fact=1;
       super.showData(val);
       for(int i=1;i<=val;i++)
       {
           fact=fact*i;
       }
       System.out.println("Factorial of "+val+" = "+fact);
    }
}
class CircleA extends Processor
{
   double area;
   void process(int val)
    {
       super.showData(val);
       area=2*3.14*val*val;
       System.out.println("Area of circle with radius "+val+" = "+area);
    } 
}
class AbstractDemo
{
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter Your Choice to find Factorial(F) or Circle(C)");
        char c=sc.next().charAt(0); 
        int n;
        switch(c)
        {
            case 'F': Factorial f=new Factorial();
            System.out.println("Enter Number to cal. Factorial");
            n=sc.nextInt();
            f.process(n);
            break;
            case 'C' :CircleA ca=new CircleA();
            System.out.println("Enter Radius of Circle to cal. Area");
            n=sc.nextInt();
            ca.process(n);
            default:
                System.out.println("Enter valid choice");
        }
    }
}