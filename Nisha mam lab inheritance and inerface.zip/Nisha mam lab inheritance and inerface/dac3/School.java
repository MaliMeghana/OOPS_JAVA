package com.dac3;

public interface School {
	public  final static String school="CDAC Mumbai";   //Explicitly it's public static final
	
	
	void StudentDetails();       //explicitly public abstract
		public abstract void TeacherDetails();

}
