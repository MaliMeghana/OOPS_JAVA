package com.dac3;

public class TestDemo {

	public static void main(String[] args) {
		Teacher t=new Teacher(101, "Shiv", "Kumar", "Java", 52, 12, "manoj", "Bhoye", 26);
		t.TeacherDetails();
		
		
		
	}
}
