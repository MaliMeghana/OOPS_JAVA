package com.dac1;

/* 
 * Display Account Details using inheritance
 * 
 */

public class AccountDetails {

	public static void main(String[] args) {
		Customer c=new Customer("Manoj", "Bhoye", "8329148983","CBI","STES","Pune");
		
			c.display();
			System.out.println("main------end");
	}

}
