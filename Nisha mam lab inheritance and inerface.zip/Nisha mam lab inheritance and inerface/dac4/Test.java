package com.dac4;

import java.util.Scanner;

public class Test {
	public static void main(String[] args) {
		
	 
		int i;
		 double total = 0;
			 	
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number of Subject");
		int n=sc.nextInt();
	
		int[] arr=new int[n];
		
		for( i=0;i<arr.length;i++)
		{
			System.out.println("Enter marks");
			arr[i]=sc.nextInt();
		}
		//sc.close();
		
		for( i=0;i<arr.length;i++)
		{
			total=total+arr[i];
			
		}
		double average=total/arr.length;
		
		System.out.println("Student average Mark :"+average);
		
	}
		
		
	
				}


