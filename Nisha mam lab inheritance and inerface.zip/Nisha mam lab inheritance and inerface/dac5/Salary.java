package com.dac5;

import java.util.Scanner;

public class Salary extends Employee implements Company {
	 private int basicsalary;
	 private int HRA ;
	 private int DA;
	 private int GS;
	 private int incometax;
	 private int netsalary;
	 
	 public void calculateSalary()  
     {
		 float basic_salary;
		double hra;
		double da;
		 double GrossPayment;

		  Scanner scan=new Scanner(System.in);

		  System.out.println("Enter Basic Salary Of Employee: ");
		  basic_salary=scan.nextFloat();

		
		  da = (0.30 * basic_salary) / 100;
		  hra = (12.5 * basic_salary) / 100;

		  GrossPayment = basic_salary + da + hra;

		  System.out.println("Gross Salary Of Employee: "+GrossPayment);
		  
     }
   
     
     
     
     
    
	public static void main(String[] args) {
		Employee emp=new Employee();
		emp.employeeDetails();
		Salary sal=new Salary();
		sal.calculateSalary();
	
	}

}
