package com.dac5;

import java.util.Scanner;

public class Employee {
	
	public int empId;
	public String empName;
	public String designation;
	public double basicSalary;
	
	 public void employeeDetails()
     {
        Scanner scan= new Scanner(System.in);
        System.out.println("Enter the employee id");//taking all the inputs from the user
        empId=scan.nextInt();
        
        System.out.println("Enter the employee name");
        empName=scan.next();
        System.out.println("Employee Id :"+empId);
        System.out.println("Emoloyee Name :"+empName);
       System.out.println("Employee Company :"+Company.companyName);
     }
	
	
	

}
