package com.dac6;

public class Manager extends Employee {

	public Manager(int empId, String empName, String address) {
		super(empId, empName, address);

	}
	void displayed()
	{
		System.out.println("hi Mahager");
	}
}
